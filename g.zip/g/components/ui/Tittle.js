import { Text , StyleSheet } from 'react-native';
import Colors from '../../constants/colors';

function Tittle({children}){
    return <Text style={styles.tiitle}>{children}</Text>
}

export default Tittle;

const styles= StyleSheet.create({
    tiitle: {
        
            fontSize: 24,
            fontWeight: 'bold',
            color: 'white',
            textAlign: 'center',
            borderWidth: 2,
            borderColor: 'white',
            padding: 12
        

    }
})