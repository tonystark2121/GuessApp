const Colors = {
    primary500: '#72064c',
    primary600: '#640233',
    primary800: '#3b021f',
    primary700: '#4e0329',
    accent500: '#ddb52f'
};

export default Colors;